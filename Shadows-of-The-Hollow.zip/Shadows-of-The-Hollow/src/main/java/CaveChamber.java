//This is the class for the CaveChamber object, representing the current location of the
//player. It is a node in the cave graph that allows the player to freely explore the map.
public class CaveChamber {
  
  //attributes
  private int id; //unique to each node
  private int[] nearbyChambers = new int[4]; //ID of adjacents in 4 directions; -1 if none in that direction (north, east, south, west)
  private boolean hasEnemy;
  private boolean hasLoot;
  private boolean visited = false;
  private boolean hasMiniBoss;
  private boolean hasFinalBoss;

  //constructor
  public CaveChamber(int id, int[] nearbyChambers, int[] events) {
    this.id = id;
    this.nearbyChambers = nearbyChambers;
    this.hasEnemy = (events[0] == 1); //matches the validity of the enclosed statement
    this.hasLoot = (events[1] == 1);
    this.hasMiniBoss = (events[2] != 0); //not limited to 0/1
    this.hasFinalBoss = (events[3] == 1);
  }
  
  /* This method returns the ID's of the adjacent chambers to a chamber.
  * 
  * @param no parameters
  *
  * @return the boolean array representing whether or not an adjacent chamber exists
  */
  public int[] getNearbyChambers() {
    return nearbyChambers;
  }

  /* This method returns the ID value of the cave chamber object.
  *
  * @param no parameters
  *
  * @return the id value, an integer
  */
  public int getID() {
    return id;
  }

  /* This method returns the visitation status of the chamber.
  *
  * @param no parameters
  *
  * @return true or false; visited already, or not?
  */
  public boolean wasVisited() {
    return visited;
  }

  /* This method is essentially a setter method for the visited attribute. It basically marks the chamber as visited.
  *
  * @param no parameters
  *
  * @return void
  */
  public void markVisited() {
    visited = true;
  }

  /* This method returns the true or false status of the chamber having an enemy.
  *
  * @param no parameters
  *
  * @return boolean value; enemy or not?
  */
  public boolean hasEnemy() {
    return hasEnemy;
  }

  /* This method returns the true or false status of the chamber having loot.
    *
    * @param no parameters
    *
    * @return boolean value; loot or not?
    */
  public boolean hasLoot() {
    return hasLoot;
  }

  /* This method returns the true or false status of the chamber having a mini boss.
    *
    * @param no parameters
    *
    * @return boolean value; mini boss or not?
    */
  public boolean hasMiniBoss() {
    return hasMiniBoss;
  }

  /* This method returns the true or false status of the chamber having the final boss.
    *
    * @param no parameters
    *
    * @return boolean value; final boss or not?
    */
  public boolean hasFinalBoss() {
    return hasFinalBoss;
  }

  /* This method returns the true or false status of the chamber having any event at all.
    *
    * @param no parameters
    *
    * @return boolean value; do any events happen for this chamber, or not?
    */
  public boolean hasEvent() {
    if(hasEnemy || hasLoot || hasMiniBoss || hasFinalBoss) { //if any of these is true, return true
      return true;
    } else { //else return false
      return false;
    }
  }
}