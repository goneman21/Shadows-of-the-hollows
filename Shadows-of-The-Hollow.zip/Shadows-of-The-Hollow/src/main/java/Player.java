// The Player class encompasses all attributes of the player, including their inventory and current weapon, as well as the Player methods.
public class Player {

  double health;
  double strength;
  String name;
  Inventory inventory = new Inventory();
  Weapon currentWeapon; 

  // constructor class
  public Player(double health, double strength, String name) {

    this.health = health;
    this.strength = strength;
    this.name = name;
  }

  // getter methods

  /* This method returns the strength value of the Player object it is called on.
  *
  * @param no parameters
  *
  * @return the strength value of the Player object; a double value
  */
  public double getStrength(){
    return strength;
  }

  /* This method returns the health value of the Player object it is called on.
    *
    * @param no parameters
    *
    * @return the health value of the Player object; a double value
    */
  public double getHealth(){
    return health;
  }

  /* This method returns the name value of the Player object it is called on.
  *
  * @param no parameters
  *
  * @return the name value of the Player object; a String value
  */
  public String getName(){

    return name;
  }

  /* This method returns the Weapon object that is considered the player's current weapon.
  *
  * @param no parameters
  *
  * @return the current weapon of the player ; a weapon object
  */
  public Weapon getWeapon() {
    return currentWeapon;
  }

  /* This method returns the inventory of the player (Inventory object)
  *
  * @param no parameters
  *
  * @return the current inventory of the player; an inventory object
  */
  public Inventory getInventory(){
    return inventory;
  }

  
  /* This method sets the strength value of the Player object to a given value.
  *
  * @param the new strength value
  *
  * @return void
  */
  public void setStrength(double strength){
    this.strength = strength;
  }

  /* This method sets the health value of the Player object to a given value.
  *
  * @param the new health value
  *
  * @return void
  */
  public void setHealth(double health){
    this.health = health;
  }

  /* This method sets the current weapon of the user to a new one.
  *
  * @param the new Weapon object
  *
  * @return void
  */
  public void setCurrentWeapon(Weapon currentWeapon){
    this.currentWeapon = currentWeapon;
  }

  /* This method sets the name value of the user to a given string.
  *
  * @param the new name value
  *
  * @return void
  */
  public void setName(String name){
    this.name = name;
  }

  // custom methods

  /* This method is essentially the value of the total damage behind each attack of the player. It returns this total value as an int value.
  *
  * @param none
  *
  * @return the total damage, with all factors considered
  */
  public int playerAttack(){
   return (int) (currentWeapon.getWeaponDamage(strength));
  }

  /* This method is an override of the predefined toString() method. It returns a string entailing the 
  * attributes of the player object it is called on in a formatted manner.
  *
  * @param no parameters
  *
  * @return a formatted string entailing the player's attributes.
  */
  @Override
  public String toString() {
    return "\nName: " + name + "\nHealth: " + health + "\nStrength: " + strength + "\n";
  }
}

  