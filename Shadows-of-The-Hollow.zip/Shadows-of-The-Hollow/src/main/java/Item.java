//This is the abstract Item superclass. It is a blueprint for the Weapon and Potion objects.
public abstract class Item{
  protected String name; // name of item

  // getter method for item name
  public String getName() {
    return name;
  }

// abstract methods for all item child classes to be used
  public abstract int use(Player player); 
  public abstract String toString();
}
