/*
Hamza, John, Kamya, Arshia
ICS4UE-21
Aug, 15, 2024
ICS4U_CPT

this is an adventure game where the player explores caves to find tresures and foes
this game aims to solve the problum with modern games being way to resourse intensive
needing expensive hardware to run.
*/


//ICS4U_CPT: Hamza, John, Kamya, Arshia
import java.util.Scanner;
import java.util.ArrayList;
import java.io.*;


public class Main {
  // for testing purposes player will be 2th param, replace with enemy later

  // method creates a enemy with randomized stats
  public static Enemy randomEnemy(){

    // returns type enemy wiht randomized stats
   return new Enemy((int)(Math.random()*(1000-500)+500), (int)(Math.random()*(50-20)+20), "Shadow"); 
  }

  /* This method validates an integer input, and returns the valid integer.
  *
  * @param the prompt to be printed to the console
  *
  * @return the valid integer input
  */
  public static int getInt(String prompt) {

    // while loop lets user re-enter info after errors
    while (true) {

      // try catch prevents program from crashing
      try {

        // prompts user for input
        System.out.println(prompt);
        int num = get.nextInt();

        // if checks if value is negative
        if ((num >= 0)){

          return num; // if not returns nim
        }

        throw new Exception();// otherwise it throws an execption
      } catch (Exception e) {
        // warns user and clears scanner value
        System.out.println("Please Enter a Non Negative Number!");
        get.nextLine();
      }
    }
  }

  /* This method ensures that an input integer is a valid index for the arraylist it's called on. 
  *
  * @param the prompt to print to the console, and the arraylist to consider
  *
  * @return the valid integer input
  */
  public static int checkIndex(String prompt, ArrayList<Item> array){

    // while loop lets user re-enter data
    while(true){

      // try catch prevents program from crashing
      try{

        // uses previous get int method to avoid negative inputs
        int num = getInt(prompt);

        // checks if number entered is within array 
        if (num < array.size()){

          // if so allows number and returns it
          return num;
        }

        // if not throws execption warns user and clears scanner value
        throw new Exception();
      }catch(Exception e){
        System.out.println("Please Enter a Number From The List Given above ");
        get.nextLine();
      }
    }
  }

  
// publicly instantiated weapon starter sword every player starts whith this
  public static Weapon starterSword = new Weapon(200.0, 0.50, "sword", 1.25, "starterSword");

  // publicly instantiated player class
  public static Player player = new Player(400.0, 123.0, "player");

  // instantiating the cave chamber 
  public static CaveChamber[] caveSystem = new CaveChamber[20];

  // publicly instantiating scanner so all methods have access to it
  public static Scanner get = new Scanner(System.in);

  // method displays all items in the players invintory
  public static void displayInv(Player player) {

    // checks if invintory has items
    if (player.getInventory().getArray().size()>0){

      // if so prints out invintory
      for (int i = 0; i < player.getInventory().getArray().size(); i++) {
        System.out.println("\n"+(i) + ")" + player.getInventory().getArray().get(i) + "\n");

      }
    }
  }

  /* This method entails the code behind fight sequences. It continually displays the current fight status, along with option for the user. If the user loses all their health,
  * the game over screen is printed, and the program ends.
  *
  * @param the player object, and an enemy object, to run the fight
  *
  * @return void
  */
  public static void fight(Player player, Enemy shadow) {

    // initilizing variubles 
    boolean battleEnd = false;
    boolean playerWin = false;
    int userChoice = 0;
    int damage = 0;
    double pHealth = player.getHealth();
    double eHealth = shadow.getHealth();

    // clears terminal 
    delayAndClear(1, true);

    // prints graphic 
    GUI.printPhoto("tentacleEnemy.txt");
    System.out.println(player.getName() + " VS " + shadow.getName());

    // clears terminal and delays next input by 3.8s
    delayAndClear(3800, true);

    // while loop runs untill battle ends
    while (!battleEnd) {

      // clears terminal
      delayAndClear(1, true);

      // prints image alongside the health of player and enemy and prints the options 
      GUI.printPhoto("playerAttacks.txt");
      System.out.println("Your Health: " + pHealth);
      System.out.println("Enemy Health: " + eHealth);
      userChoice = getInt("Battle Menu:\n1) Attack\n2) Items");

      // checks user choice
      if (userChoice == 1) {

        // if user picked attack 
        damage = player.playerAttack();

        // prints damage and takes the ammount away from the enemy
        System.out.println("You dealt " + damage + " Damage!");
        eHealth -= damage;

        // checks if the enemy is dead to prevent negative values from printing
        if (eHealth <0){

          // if enemy health is below 0 (means enemy lost) prints such 
          System.out.println(shadow.getName() + " has no health remaining!");
        }else {

          // otherwise prints the ammount of health enemy has left
          System.out.println(shadow.getName() + " has " + eHealth + " remaining!");
        }

        // if user decides to use an item
      } else if (userChoice == 2) {

        // checks if invintory is empty
        if (!(player.getInventory().getArray().size()==0)){

          // if not displays players invintory
          displayInv(player);

          // gets user choice on what item user would like to user
          userChoice = checkIndex("Which Item do you want to use? Enter the corresponding number to choose:", player.getInventory().getArray());

          // adds the health from potion to user (if user decided to equip a new weapon it will not add any health)
          pHealth += player.getInventory().getItem(userChoice).use(player);
          } else {

          // if invintory is empty informs player and continues gaem
            System.out.println("You take a look in your bag, only to find nothing. Turn over!");
          }

      }

      // clears console and waits 2s
      delayAndClear(2000, false);

      // enemy attacks user
      System.out.println(shadow.getName() + " attacked! You lost " + shadow.attack() + " Health.");
      pHealth -= shadow.attack();

      // checks if user lost or won and ends battle accordingly
      if (eHealth <= 0) {
        playerWin = true;
        battleEnd = true;
        System.out.println("YOU WON");

        delayAndClear(3500, true);
        return;
        
      } else if (pHealth <= 0) {

        // if user lost ends game
        battleEnd = true;
        delayAndClear(2800, true);
        
        System.out.println("You fell in battle. The shadows overpowered you.");
        delayAndClear(2800, false);
        
        System.out.println("Rest well, wherever you are.");
        delayAndClear(2800, false);

        System.out.println("GAME OVER");
        System.exit(0); //end program
      } 

      // clears console and delays by 2.5s
      delayAndClear(2500, true);
    }
  }

  /*
   * This method instantiates all 20 CaveChamber object directly, using the
   * constructor.
   *
   * @param no parameters
   *
   * @return void
   */

  public static void instantiateMap() {
    // manual instantiation of all 20 CaveChamber objects, using the public static  
    // attribute caveSystem
    // CaveChambers 0 - 9
    caveSystem[0] = new CaveChamber(0, new int[] { 1, -1, -1, -1 }, new int[] { 0, 0, 0, 0 });
    caveSystem[1] = new CaveChamber(1, new int[] { 5, 2, 0, 4 }, new int[] { 0, 0, 0, 0 });
    caveSystem[2] = new CaveChamber(2, new int[] { 6, 3, -1, 1 }, new int[] { 1, 0, 0, 0 });
    caveSystem[3] = new CaveChamber(3, new int[] { -1, -1, -1, 2 }, new int[] { 0, 1, 0, 0 });
    caveSystem[4] = new CaveChamber(4, new int[] { -1, 1, -1, -1 }, new int[] { 0, 1, 0, 0 });
    caveSystem[5] = new CaveChamber(5, new int[] { 7, 6, 1, -1 }, new int[] { 1, 0, 0, 0 });
    caveSystem[6] = new CaveChamber(6, new int[] { -1, -1, 2, 5 }, new int[] { 0, 0, 0, 0 });
    caveSystem[7] = new CaveChamber(7, new int[] { 11, -1, 5, 8 }, new int[] { 0, 1, 0, 0 });
    caveSystem[8] = new CaveChamber(8, new int[] { -1, 7, -1, 9 }, new int[] { 0, 0, 0, 0 });
    caveSystem[9] = new CaveChamber(9, new int[] { -1, 8, 10, -1 }, new int[] { 0, 0, 1, 0 });

    // CaveChambers 10 - 19
    caveSystem[10] = new CaveChamber(10, new int[] { 9, -1, -1, -1 }, new int[] { 0, 1, 0, 0 });
    caveSystem[11] = new CaveChamber(11, new int[] { -1, 12, 7, -1 }, new int[] { 0, 0, 2, 0 });
    caveSystem[12] = new CaveChamber(12, new int[] { 13, 18, -1, 11 }, new int[] { 0, 0, 0, 0 });
    caveSystem[13] = new CaveChamber(13, new int[] { 19, 14, 12, -1 }, new int[] { 0, 1, 0, 0 });
    caveSystem[14] = new CaveChamber(14, new int[] { -1, 15, 18, 13 }, new int[] { 0, 0, 0, 0 });
    caveSystem[15] = new CaveChamber(15, new int[] { 16, -1, -1, 14 }, new int[] { 0, 0, 3, 0 });
    caveSystem[16] = new CaveChamber(16, new int[] { 17, -1, 15, -1 }, new int[] { 0, 1, 0, 0 });
    caveSystem[17] = new CaveChamber(17, new int[] { -1, -1, 16, -1 }, new int[] { 0, 0, 0, 1 });
    caveSystem[18] = new CaveChamber(18, new int[] { 14, -1, -1, 12 }, new int[] { 1, 0, 0, 0 });
    caveSystem[19] = new CaveChamber(19, new int[] { -1, -1, 13, -1 }, new int[] { 1, 0, 0, 0 });
  }

  public static void main(String[] args) {
    // creates the map
    instantiateMap();

    // initilizing the current chamber id
    int currChamberID;

    // read
    File file = new File("savedData.txt");

    // loading saved data if chosen
    System.out.println("Do you have a saved playthrough? Would you like to resume from it? Y/N:");
    String answer = get.next();
    get.nextLine();

    
    System.out.println("Loading...");
    if (answer.equalsIgnoreCase("Y") && file.length() > 3) { // if 'Y' entered, load prev data
      ArrayList<Object> dataToLoad = new ArrayList<Object>(); // list of type object to hold any type

      // adds data to a variuble for easy acces
      dataToLoad = loadData();

      // gets and adds current chamber id to game 
      currChamberID = (Integer) dataToLoad.get(0);
      System.out.println("Chamber ID loaded...");

      // gets and adds player save data to game
      player = (Player) dataToLoad.get(1);
      System.out.println("Player object loaded...");

      int index = 2;

      // checks if item is weapon and adds to invintory aproperatly 
      while (dataToLoad.get(index) instanceof Weapon) {
        player.getInventory().addItem((Weapon) dataToLoad.get(index));
        index++;
      }

      System.out.println("Weapons loaded...");

      // checks for potion items and adds them to invintory
      while (dataToLoad.get(index) instanceof Potion) {
        player.getInventory().addItem((Potion) dataToLoad.get(index));
        index++;
      }

      System.out.println("Potions loaded...");

      
      // saves visited chamber information to temporary boolean array
      boolean[] visitedChambers = (boolean[]) dataToLoad.get(index);

      // for indexes through array and adds the values to game
      for (int i = 0; i < 20; i++) {
        if (visitedChambers[i]) {
          caveSystem[i].markVisited();
        }
      }

      // set player weapon to default starter sword
      player.setCurrentWeapon(starterSword);

      // informs player loading was successful
      System.out.println("Visitation status loaded.");
      System.out.println("");
      System.out.println("Loading successful!");
      delayAndClear(3000, true);
      
      System.out.println("Your current stats:\n" + player.toString());
      System.out.println("Your inventory has " + player.getInventory().getArray().size() + " items.");
      System.out.println("");
      delayAndClear(5000, true);

    } else {
      if (answer.equalsIgnoreCase("Y") && file.length() == 0) { // if no file found, print extra message
        System.out.println("Valid save file not found. Starting new playthrough...");
      }

      // if user wants to start a new game
      delayAndClear(2000, true);
      answer = "";
      // opening statements for new save
      System.out.println("Hey! You there. You look like quite the fighter.");

      delayAndClear(2000, false);

      // sets name and adds starter sword to the invintory as it is the default
      System.out.println("What's your name?");
      player.setName(getName());
      player.setCurrentWeapon(starterSword);
      player.getInventory().addItem(starterSword);
      get.nextLine();

      // prints intro sequence
      printIntro();

      currChamberID = 0; // to store the id of the chamber player is in; player starts at 0
    }

    // main loop/'the real game'
    boolean gameRunning = true; // condition for the loop
    int endChamberID = 17; //condition for win
    while (gameRunning) { // repeats until a valid ending is reached
      if(currChamberID==endChamberID) {
        delayAndClear(1, true);
        GUI.printPhoto("cloakedFigureText.txt");
        System.out.println("The final boss......");
        delayAndClear(4000, true);
        fight(player, new Enemy(1000, 150, "The Shadow"));
        printOutro();
        
      }
      // conditional to run different code based on the current chamber
      // if event, run event then go to the "move to adjacent chamber" menu
      if (caveSystem[currChamberID].hasEvent() && !caveSystem[currChamberID].wasVisited()) {

        // determine whether or not theres an enemy
        if (caveSystem[currChamberID].hasEnemy()) {
          delayAndClear(1, true);
          System.out.println("Chamber " + currChamberID + " has an enemy!");
          delayAndClear(4000, true);
          fight(player, randomEnemy());

          // checks if the chamber has loot
        } else if (caveSystem[currChamberID].hasLoot()) {
          GUI.printPhoto("lootChamber.txt");
          System.out.println("There seems to be an item in this chest! It's in your inventory now.");
          player.getInventory().addRandItem();

          delayAndClear(7000, true);

          // checks if chamber has a mini-boss
        } else if (caveSystem[currChamberID].hasMiniBoss()){
          delayAndClear(1, true);
          GUI.printPhoto("cloakedFigureText.txt");
          System.out.println("A powerful opponent appears");
          delayAndClear(4000, true);
          fight(player, new Enemy(1001, 100, "Fragment of the Shadows"));
          
        }

        caveSystem[currChamberID].markVisited(); //mark as visited
      }

      // save current data
      saveData(currChamberID, player);
      // if no event/chamber already visited, go straight to the "next options" part
      currChamberID = moveChambers(caveSystem[currChamberID]);
      System.out.println("Travelling through the tunnel...");
      delayAndClear(2800, true);
    }

    System.out.println(player.toString()); // top bar displays stats
    // fight(player, player2)
    // GUI.printRedPixel();
  }

  /* This method entails the process of moving chambers. It displays the adjacent chambers and their directions, takes user input on which direction to go, validates it, and then
  * returns the ID value of the new chamber.
  *
  * @param the current caveChamber object that the user is considered to be in
  *
  * @return the ID value of the adjacent chamber that user moved to.
  */
  public static int moveChambers(CaveChamber chamber) {
    int newID = 0; // id of new chamber
    int userChoice = 0; // direction chosen by user
    int[] adjIDs = chamber.getNearbyChambers();
    int adjCount = 0; // # of valid adjacents
    boolean[] adjDirections = new boolean[4]; // tracks whether or not there is adjacent in each of 4 directions

    //printing image
    GUI.printPhoto("3cavesText.txt");

    // displaying info to user
    System.out.println("(If you want to exit the program, press Ctrl + C. Your data has been saved.)");
    System.out.println("There are tunnels going in the following directions:");

    // printing directions if they exist
    if (adjIDs[0] != -1) {
      adjDirections[adjCount] = true;
      adjCount++;
      System.out.println(adjCount + ". North");
    }

    if (adjIDs[1] != -1) {
      adjDirections[adjCount] = true;
      adjCount++;
      System.out.println(adjCount + ". East");
    }

    if (adjIDs[2] != -1) {
      adjDirections[adjCount] = true;
      adjCount++;
      System.out.println(adjCount + ". South");
    }

    if (adjIDs[3] != -1) {
      adjDirections[adjCount] = true;
      adjCount++;
      System.out.println(adjCount + ". West");
    }

    System.out.println("");
    System.out.println("Make your choice by entering the corresponding number.");

    // choice validation
    boolean validChoice = false; // loop condition
    while (!validChoice) { // repeats until choice is valid
      try {
        userChoice = get.nextInt();

        if (userChoice < 1 || userChoice > adjCount) { // if out-of-range, throw exception
          throw new Exception("This value must range from 1 to " + adjCount + "!");
        }

        validChoice = true; // if no issues, break loop
      } catch (Exception e) {
        get.nextLine();
        if (e.getMessage() != null) { // if custom exception, print custom warning
          System.out.println(e.getMessage());
        }

        System.out.println("Invalid input. Try again:");
      }
    }

    // determining ID of the node to move to
    int temp = 0; // temp variable to help in the process
    for (int i = 0; i < 4; i++) {
      if (adjIDs[i] != -1) {
        temp++;
        if (temp == userChoice) {
          newID = adjIDs[i];
          break;
        }
      }
    }

    return newID;
  }

  /*
   * This method saves the current game data to savedData.txt. It saves the
   * current location, stats of the player, their inventory items, and the visitation status of every caveChamber object.
   *
   * @param the ID of the current chamber, and the Player object
   *
   * @return void
   */
  public static void saveData(int currChamberID, Player player) {
    try {
      BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("savedData.txt"));

      bufferedWriter.write(String.valueOf(currChamberID) + "\n"); // current location

      // player attributes
      bufferedWriter.write(player.getName() + "\n");
      bufferedWriter.write(String.valueOf(player.getHealth()) + "\n");
      bufferedWriter.write(String.valueOf(player.getStrength()) + "\n");

      // inventory/item attributes (weapons/potions)
      for (Item itemToSave : player.getInventory().getArray()) {
        if (itemToSave instanceof Weapon) {
          Weapon exampleWeapon = (Weapon) itemToSave;

          // printing the attributes, separated by commans
          bufferedWriter.write("W,");
          bufferedWriter.write(String.valueOf(exampleWeapon.getPower()) + ",");
          bufferedWriter.write(String.valueOf(exampleWeapon.getCritChance()) + ",");
          bufferedWriter.write(exampleWeapon.getType() + ",");
          bufferedWriter.write(String.valueOf(exampleWeapon.getCritDamageMultiplier()) + ",");
          bufferedWriter.write(exampleWeapon.getName() + "\n");

        } else if (itemToSave instanceof Potion) {
          Potion examplePotion = (Potion) itemToSave;

          // printing the attributes, separated by commas
          bufferedWriter.write("P,");
          bufferedWriter.write(String.valueOf(examplePotion.getHealAmount()) + ",");
          bufferedWriter.write(examplePotion.getName() + "\n");
        }
      }

      // cave chamber object attributes
      for (int i = 0; i < 20; i++) { // loops for every chamber
        if (caveSystem[i].wasVisited()) { // if visited print 1, if not, print 0
          bufferedWriter.write(String.valueOf(1));
        } else {
          bufferedWriter.write(String.valueOf(0));
        }
      }

      bufferedWriter.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /*
   * This method reads the data from savedData.txt, and returns the relevants
   * values to the main method
   * accordingly (in the form of an arraylist of type Object) to help resume the game from the
   * player's previous save.
   *
   * @param no parameters
   *
   * @return
   */
  public static ArrayList<Object> loadData() {
    ArrayList<Object> data = new ArrayList<Object>();
    boolean[] visitedChamber = new boolean[20];

    try {
      BufferedReader bufferedReader = new BufferedReader(new FileReader("savedData.txt"));

      // location
      data.add(Integer.parseInt(bufferedReader.readLine()));

      // loading player stats
      String name = bufferedReader.readLine().trim();
      double health = Double.parseDouble(bufferedReader.readLine());
      double strength = Double.parseDouble(bufferedReader.readLine());

      data.add(new Player(health, strength, name));

      // inventory/item attributes (weapons/potions)
      String itemString = "";

      while (bufferedReader.ready()) { // loops until every line read
        itemString = bufferedReader.readLine();
        String[] itemArray = itemString.split(",");

        if (itemString.startsWith("W")) { // read weapon and load it

          // add new weapon object
          data.add(new Weapon(Double.parseDouble(itemArray[1]), Double.parseDouble(itemArray[2]), itemArray[3],
              Double.parseDouble(itemArray[4]), itemArray[5]));
        } else if (itemString.startsWith("P")) { // read potion and load it

          // add new potion object
          data.add(new Potion(Integer.parseInt(itemArray[1]), itemArray[2]));
        } else { // read and load visitation status of all chambers, outside of the loop
          break;
        }
      }

      String visitationData = bufferedReader.readLine();
      for (int i = 0; i < 20; i++) { // repeats once for every caveChamber object
        if(visitationData != null) {
          if (visitationData.charAt(i) == '1') { // if visited, update bool array accordingly
            visitedChamber[i] = true;
          } else {
            visitedChamber[i] = false;
          }
        } else {
          visitedChamber[i] = false;
        }
      }

      data.add(visitedChamber);

      bufferedReader.close();
    } catch (Exception e) {
      e.printStackTrace();
    }

    return data;
  }

  /* This void method prints the intro sequence, implementing delays and console clearing at the end. It is a cosmetic method.
  *
  * @param no parameters
  *
  * @return void
  */
  public static void printIntro() {
    System.out.println("");
    System.out.println(player.getName() + ", eh?");
    delayAndClear(1800, false);

    System.out.println("Doesn't matter. You came here for something greater than any name.");
    delayAndClear(3000, false);

    System.out.println("Behind us lies The Hollow, home to countless treasures and treacherous shadows.");
    delayAndClear(3000, false);

    System.out.println("It's your job to get in there, take what's inside, and get out!");
    delayAndClear(3000, false);

    System.out.println("Remember: If you die without my permission, I'll kill you.");
    delayAndClear(2800, false);

    System.out.println("Now get to it!");
    System.out.println("");

    delayAndClear(2800, true);
  }

  /* This void method prints the outro sequence, implementing delays and console clearing at the end. It is a cosmetic method.
    *
    * @param no parameters
    *
    * @return void
    */
  public static void printOutro() {
    System.out.println("");
    System.out.println("Not a bad journey, eh, " + player.getName() + "?");
    delayAndClear(1800, false);

    System.out.println("Well, what's done is done. You braved The Hollow!");
    delayAndClear(3000, false);

    System.out.println("You took what is rightfully yours, and defeated any shadows that came your way.");
    delayAndClear(3000, false);

    System.out.println("I call this a job well done!");
    delayAndClear(3000, true);

    System.out.println("GAME OVER");
    delayAndClear(2800, false);

    System.out.println("You won! You successfully survived The Hollows.");
    System.exit(0);
  }

  /* This method causes a delay of a given amount of milliseconds, and also clears the console if
  * specified.
  *
  * @param no parameters
  *
  * @return void
  */
  public static void delayAndClear(int ms, boolean clear) {
    try {
      Thread.sleep(ms);
    } catch (Exception e) {
      e.printStackTrace();
    }

    if(clear) { //clear console if specified
      //clearing console
      System.out.print("\033[H\033[2J");
      System.out.flush();
    }
  }

  /* This method validates a String input to be non-empty, and returns the valid String.
  *
  * @param no parameters
  *
  * @return the valid, non-empty String
  */
  public static String getName() {
    String validName = "";
    boolean validInput = false; //loop condition
    
    while(!validInput) { //repeats until valid input
      validName = get.next();

      if(!validName.isEmpty()) { //if non-empty, break loop
        validInput = true;
      }
    }

    return validName;
  }
}