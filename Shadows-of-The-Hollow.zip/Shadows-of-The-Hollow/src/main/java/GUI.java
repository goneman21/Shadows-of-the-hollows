import java.io.BufferedReader;
import java.io.FileReader;


/* This class encompasses the whole of the "photo printing" process. The concepts used in this were derived mostly from these: 
* https://stackoverflow.com/questions/5762491/how-to-print-color-in-console-using-system-out-println
* https://stackoverflow.com/questions/4842424/list-of-ansi-color-escape-sequences
*/
public class GUI {
  
  /* This method encompasses part of the "photo printing" process. It reads the RGB values for the
  * image from the file, stores them, then processes them using the other method/prints them.
  *
  * @param fileName; path of the file with RGB data
  *
  * @return void
  */
  public static void printPhoto(String fileName) {
    //3d array to store RGB data
    int[][][] imgPixels = new int[40][40][3];

    //read the file & fill array
    try {
      BufferedReader bufferedReader = new BufferedReader(new FileReader(fileName));
      String line = "";
      int row = 0;
      int col = 0;

      while(bufferedReader.ready()) { //repeats until no lines left
        line = bufferedReader.readLine();

        //finding start index of each value
        int redIndex = line.indexOf("R=") + 2;
        int greenIndex = line.indexOf("G=") + 2;
        int blueIndex = line.indexOf("B=") + 2;

        //reading + storing each color's value
        int redValue = Integer.parseInt(line.substring(redIndex, line.indexOf(",", redIndex)));
        int greenValue = Integer.parseInt(line.substring(greenIndex, line.indexOf(",", greenIndex)));
        int blueValue = Integer.parseInt(line.substring(blueIndex));

        imgPixels[row][col][0] = redValue;
        imgPixels[row][col][1] = greenValue;
        imgPixels[row][col][2] = blueValue;

        //move to next col/row
        col++;
        if(col==40) {
          col = 0;
          row++;
        }
      }
    } catch(Exception e) {
      System.out.println("Error printing image.");
      e.printStackTrace();
      return;
    }

    //print image
    printImage(imgPixels);
  }

  /* This method goes through the 3D array imgPixel, and prints each 'pixel' using another method.
  *
  * @param imgPixel; the 3d array storing all RGB values
  *
  * @return void
  */
  public static void printImage(int[][][] imgPixels) {
    for(int i = 0; i < 40; i++) { //repeats 40 times
      for(int j = 0; j < 40; j++) { //repeats 40 times
        int red = imgPixels[i][j][0];
        int green = imgPixels[i][j][1];
        int blue = imgPixels[i][j][2];

        printPixel(red, green, blue);
      }
      System.out.println(""); //newline after each row
    }
  }

  /* This method prints a colored character following a given RGB value, using ANSI escape codes.
  *
  * @param the RGB values of the color to print; red, green, blue
  *
  * @return void
  */
  public static void printPixel(int redValue, int greenValue, int blueValue) {
    System.out.print("\033[48;2;" + redValue + ";" + greenValue + ";" + blueValue + "m  ");
    System.out.print("\033[0m");
    
  }
}