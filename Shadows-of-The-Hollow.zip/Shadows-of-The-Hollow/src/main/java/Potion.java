// This class is a subclass of item. It encompasses the Potion object, including its attributes, such as the heal value, and methods.
public class Potion extends Item {

  // initilizing the attributes of the potion class
  private int healAmount;

  // constructor for potion class
  public Potion(int healthHeal, String name){

    this.healAmount = healthHeal;
    this.name = name;
  }

  /* This method entails the consumption of a potion. It deletes the potion, sorts the inventory, and returns the heal amount of the potion used.
  *
  * @param the player object
  *
  * @return the heal value of the potion
  */
  @Override
  public int use(Player player) {

    // by using the item the user consumes it removing it from invintory
    player.getInventory().deleteItem(this);

    // reorganizes invintory after removing item
    player.getInventory().sortInventory();
    System.out.println("You used a potion to heal" + healAmount); 

    // returns the heal ammount to be added to the instance of health player has in battle
    return healAmount;
  }

  /* This method returns the name value of the potion.
    *
    * @param no parameters
    *
    * @return potion name
    */
  @Override
  public String getName() {
    return name;
  }

  /* This method returns the heal value of the potion.
    *
    * @param no parameters
    *
    * @return int value of heal amount
    */
  public int getHealAmount() {
    return healAmount;
  }

  /* This method overrides the predefined toString() method to display the attributes of the potion in a formatted manner.
    *
    * @param no parameters
    *
    * @return a String with all the attributes, formatted nicely
    */
  @Override
  public String toString() {
    return "Potion\nHeal Amount: " + healAmount + " \nName:" + name + "\n";
  }
  
}
