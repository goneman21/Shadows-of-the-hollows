//This is the Enemy class. It entails general attributes such as healthPoints and dmgPerAttack. It also contains the relevant methods for an enemy object.

public class Enemy {

    private String name; // Declaring a private variable string name
    private int healthPoints; // Declaring a private int healthPoints variable
    private int dmgPerAttack; // Declaring a private int dmgPerAttack variable

    /*
    * Constructor: Enemy
    * Description: This method is the constructor of the Enemy class
    * Arguments: int healthPoints, int dmgPerAttack
    * Job: sets the values of the instance attributes healthPoints and dmgPerAttack to the respective parameters
    */
    public Enemy (int healthPoints, int dmgPerAttack, String name) 
  {
    this.healthPoints = healthPoints; 
    this.dmgPerAttack = dmgPerAttack;
    this.name = name;
  }

  /*
  * Method: getHealthPoints
  * Description: this getter method returns the total healthPoints of the enemy
  * Params: none
  * Returns: the private variable healthPoints
  */
  public int getHealth() 
  {
    return healthPoints;
  }

  /*
  * Mehod: getName
  * Description: this getter method returns the name of the enemy
  * Params: none
  * Returns: the private variable name
  */
  public String getName(){

    return name;
  }
  
  /*
  * Method: getDmgPerAttack
  * Description: this getter method returns the total damage on the player by the enemy
  * Params: none
  * Returns: the private variable dmgPerAttack
  */
  public int getDmgPerAttack()
  {
    return dmgPerAttack;
  }

  /*
  * Method: setHealthPoints
  * Description: this setter method sets the total healthPoints of the enemy
  * Params: int healthPoints
  * Returns: void
  * Job: sets the private variable healthPoints to the parameter healthPoints
  */
  public void setHealthPoints (int healthPoints)
  {
    this.healthPoints = healthPoints;
  }

  /*
  * Method: setDmgPerAttack
  * Description: this setter method sets the total dmgPerAttack of the enemy to the player
  * Params: int dmgPerAttack
  * Returns: void
  * Job: sets the private variable dmgPerAttack to the parameter dmgPerAttack
  */
  public void setDmgPerAttack (int dmgPerAttack)
  {
    this.dmgPerAttack = dmgPerAttack;
  }

  /*
  * Method: attack
  * Description: this method deals damage to the player
  * Params: Player player // this is the player object that will be attacked
  * Returns: void
  * Job: deals damage to the player by subtracting the damage of the enemy (which is set to 10 by default for each hit) from the player's health
  */
  public int attack (/*Player player*/)
  {
    // player.setHealth (player.getHealth() - dmgPerAttack);

    return dmgPerAttack;
  }

  
}