import java.util.*;

/* This class entails the attributes and methods regarding the inventory of the player. It can store items, retrieve them, manipulate them, etc. */
public class Inventory {

  private ArrayList<Item> items; // items of invintory get stored to array

  // constructor
  public Inventory(){
    this.items = new ArrayList<Item>();
    
  }

  /* This method adds a new item to the items arraylist.
    *
    * @param the Item object to add
    *
    * @return void?
    */
  public void addItem(Item item) {
    items.add(item);

  }

  /* This method adds a random item to the user's inventory, of varying type and stats. It then displays the information of the new item.
    *
    * @param no parameters
    *
    * @return void
    */
  public void addRandItem() {
    Random random = new Random();

    // decide whether or not to add weapon (1/4 chance)
    if (random.nextInt(4) == 0) {
      // add weapon
      Weapon newWeapon = new Weapon((235 + (random.nextInt(51) - 35)), 0.70, "sword",
          (1.1 + ((random.nextInt(51)) / 100.0)), ("Rusty Sword"));

      System.out.println("Here's the Weapon you received:" + newWeapon.toString());
      items.add(newWeapon);
    } else {
      // add potion
      Potion newPotion = new Potion(random.nextInt(130) + 100, ("Health Potion"));

      System.out.println("Here's the Potion you received:\n" + newPotion.toString());
      items.add(newPotion);
    }
  }

  /* This method removes a given Item object from the array list
    *
    * @param the Item to delete
    *
    * @return void
    */
  public void deleteItem(Item item) {
    items.remove(item);
  }

  /* This method returns the arraylist items.
    *
    * @param no parameters
    *
    * @return the items arraylist
    */
  public ArrayList<Item> getArray() {
    return items;
  }

  /* This method retrieves an item from a given index, returning null if it doesn't exist
    *
    * @param the index to search for
    *
    * @return the relevant item, or null if it doesnt exist
    */
  public Item getItem(int index) {
   if(index == -1) {
     return null;
   }
    
    return items.get(index);
  }

  /* This method sorts the inventory array in alphabetic order.
    *
    * @param no parameters
    *
    * @return void
    */
  public void sortInventory() {

    // declaring variubles
    boolean swapped;

    // index through array
    for (int i = 0; i < items.size() - 1; i++) {
      swapped = false;

      // checks item next to item i
      for (int j = 0; j < items.size() - 1 - i; j++) {

        // compair names of ajacent items alphabeticly using compare to
        if (items.get(j).getName().compareTo(items.get(j + 1).getName()) > 0) {
          // if the current item is alphabetcly greater than the next item they get swapped
          
          Item temp = items.get(j);
          items.set(j, items.get(j + 1));
          items.set(j + 1, temp);
          swapped = true;
        }
      }

      // if no swapes were made this means the array is sorted and ends the method
      if (!swapped) {

        return;
      }
    }

  }

  /* This method finds the index of an item by its name value.
    *
    * @param the item's name
    *
    * @return the relevant item's index, or -1 if it doesnt exist.
    */
  public int findItemIndex(String itemName) {

    // indexes through array
    for (int i = 0; i < items.size(); i++) {

      // checks if name is equal to the name of the item looking for
        if (items.get(i).getName().equals(itemName)){

          // returns index of item
        return i;  
        }
      }

    // if not found returns -1
      return -1;
  }

  /* This method returns the heal value of a potion object. It is a bit different from the one in Potion.java and is implemented differently; both are necessary.
    *
    * @param the item, assumed to be a potion (verified outside)
    *
    * @return the heal value
    */
  public int getHealAmount(Item item) {

    // initilizing heal ammount
    int heal = 0;

    // checks if item is of type potion to avoid errors
    if(item instanceof Potion) {

      // casts item to potion
      Potion potionToUse = (Potion) item;

      // saves heal ammount to int variable
      heal = potionToUse.getHealAmount();
    }

    //returning heal ammount variable
    return heal;
  }
}