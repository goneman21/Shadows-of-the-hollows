import java.util.Random;
// This class is a subclass of Item. It encompasses the Weapon object, including its attributes, such as damage, and methods.
public class Weapon extends Item {

  // initilizing the weapon atributes
  private double power;
  private double critChance;
  private String type;
  private double critDamageMultipiler;

  // constructor for Weapon 

  public Weapon(double power, double critChance, String type, double critDamageMultiplier, String name) {

    this.power = power;
    this.critChance = critChance;
    this.type = type;
    this.critDamageMultipiler = critDamageMultiplier;
    this.name = name;
  }

  // implementing the use method from item class
  @Override
  public int use(Player player){

    // equippes weapon by setting to current method
    System.out.println("Equipped "+ name);
    player.setCurrentWeapon(this);
    return 0;
  }

  
  // getter methods for atributes 

  // gets power of weapon
  public double getPower() {

    return power;
  }

  // getter for the crtical chance of the weapon
  public double getCritChance() {

    return critChance;
  }

  // getter for the weapon type
  public String getType(){

    return type;
  }

  // getter for the critical damage multiplier
  public double getCritDamageMultiplier(){

    return critDamageMultipiler;
  }

  // get weapon damage calculates how much damage the weapon dose
  // with the user who uses it
  public double getWeaponDamage(double userStrength){

    // random to implement the critical hit feture
    Random random = new Random();

    double randValue = random.nextDouble();

    // checks if the critical chance is bigger than the random value
    // this accuratly implements the chance of getting a critical hit
    if(randValue < critChance){

      // if player gets critical hit prints as such and multiplies by the critical hit multiplier
      System.out.println("Critical Hit!");
      return ((power*userStrength)/100)*critDamageMultipiler;
      
    }else{

      // if no critical hit occors the damage is calculated regularly
      return ((power*userStrength)/100);
    }
  }

  // to string method to return weapon info in a readable format
  @Override
  public String toString() {
    return name+"\nWeapon Type: " + type + "\nPower: " + power + "\nCrit. Chance: " + (critChance * 100.0) + "%\nCrit. Damage Multiplier: " + critDamageMultipiler + "x\n";
  }
}